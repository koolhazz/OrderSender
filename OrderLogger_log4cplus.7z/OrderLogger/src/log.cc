#include "log.h"

Logger *g_logger = NULL;

int
init_log(const char* conf)
{
	PropertyConfigurator::doConfigure(conf);

	g_logger = new Logger(Logger::getRoot());
	
	return 0;	
}

