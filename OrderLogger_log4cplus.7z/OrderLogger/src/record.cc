#include "record.h"
#include "log.h"
#include "RedisHelper.h"
#include "conf.h"

#include <string>

using std::string;

typedef class CRedisHelper redis_helper_t;

extern conf_t *g_conf;

int
order_log_recording(redis_helper_t* redis)
{
	string log;

	log_info("order_log_recording begin");
	if (redis && redis->IsActived()) {
		redis->Dequeue(g_conf->redis_key, log);
		if (!log.empty()) {
			log_info(log.c_str());
		}
	}		
	log_info("order_log_recording end");
	return 0;
}

