#ifndef __LOG_H_
#define __LOG_H_

#include "log4cplus/logger.h"
#include "log4cplus/fileappender.h"
#include "log4cplus/loglevel.h"
#include "log4cplus/configurator.h"
#include "log4cplus/loggingmacros.h"

using namespace log4cplus;
using namespace log4cplus::helpers;

extern Logger *g_logger;
/*
#define log_debug(fmt, args...) LOG4CPLUS_DEBUG_FMT(g_logger, fmt, ##args)
#define log_info(fmt, args...) 	LOG4CPLUS_INFO_FMT(g_logger, fmt, ##args)
#define log_error(fmt, args...) LOG4CPLUS_ERROR_FMT(g_logger, fmt, ##args)*/

#define log_debug(msg) 	LOG4CPLUS_DEBUG(*g_logger, msg)
#define log_info(msg) 	LOG4CPLUS_INFO(*g_logger, msg)
#define log_error(msg) 	LOG4CPLUS_ERROR(*g_logger, msg)

int
init_log(const char* conf);


#endif 
