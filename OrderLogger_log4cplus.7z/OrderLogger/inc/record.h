#ifndef __RECORD_H_
#define __RECORD_H_

typedef class CRedisHelper redis_helper_t;

int
order_log_recording(redis_helper_t* redis);

#endif 

